package com.example.data.repository

import android.util.Log
import com.example.core.config.SupabaseConfig
import com.example.core.session.SessionManager
import com.example.data.remote.client.SupabaseClientFactory
import com.example.data.remote.dto.SupabaseRefreshTokenRequest
import com.example.data.remote.dto.SupabaseResetPasswordRequest
import com.example.data.remote.dto.SupabaseSignInRequest
import com.example.domain.model.Permission
import com.example.domain.model.SupabaseStatus
import com.example.domain.model.UserProfile
import com.example.domain.model.UserRole
import com.example.domain.model.UserSession
import com.example.domain.repository.AuthRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext

/**
 * Repositório de autenticação conectado aos endpoints reais do Supabase GoTrue e à tabela 'perfis'.
 */
class SupabaseAuthRepositoryImpl(
    private val sessionManager: SessionManager,
    private val clientFactory: SupabaseClientFactory = SupabaseClientFactory(sessionManager)
) : AuthRepository {

    private val TAG = "CIADI_AUTH"

    override val sessionFlow: StateFlow<UserSession> = sessionManager.sessionFlow

    override suspend fun signInWithEmail(email: String, password: String): Result<UserProfile> = withContext(Dispatchers.IO) {
        val trimmedEmail = email.trim()
        val trimmedPass = password.trim()

        if (trimmedEmail.isBlank() || trimmedPass.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Informe o e-mail e a senha de acesso."))
        }

        Log.d(TAG, "Iniciando autenticação no Supabase Auth para: $trimmedEmail (Endpoint: ${SupabaseConfig.tokenUrl})")

        try {
            // 1. Chamada direta ao endpoint oficial do Supabase GoTrue
            val response = clientFactory.authApi.signInWithPassword(
                request = SupabaseSignInRequest(email = trimmedEmail, password = trimmedPass)
            )

            Log.d(TAG, "Resposta recebida do Supabase Auth: HTTP ${response.code()}")

            if (response.isSuccessful) {
                val authResponse = response.body()
                val userDto = authResponse?.user
                val accessToken = authResponse?.accessToken.orEmpty()
                val refreshToken = authResponse?.refreshToken.orEmpty()

                if (userDto == null || accessToken.isBlank()) {
                    return@withContext Result.failure(Exception("Supabase Auth retornou credenciais vazias."))
                }

                val userId = userDto.id
                Log.d(TAG, "Usuário autenticado com sucesso no Supabase GoTrue! user.id = $userId")

                // 2. Busca o perfil correspondente na tabela 'perfis'
                var profile = fetchProfileFromDatabase(userId, trimmedEmail, accessToken)

                if (profile == null) {
                    // Fallback estruturado a partir dos metadados do GoTrue caso a tabela ainda não contenha o registro
                    val roleStr = userDto.userMetadata?.get("role") ?: userDto.role
                    val role = UserRole.fromCode(roleStr)
                    val fullName = userDto.userMetadata?.get("full_name") ?: userDto.userMetadata?.get("name") ?: trimmedEmail.substringBefore("@")

                    profile = UserProfile(
                        id = userId,
                        email = userDto.email ?: trimmedEmail,
                        fullName = fullName,
                        role = role,
                        specialty = userDto.userMetadata?.get("specialty"),
                        unitName = userDto.userMetadata?.get("unit_name") ?: "CIADI — Centro Integrado",
                        permissions = Permission.defaultPermissionsFor(role)
                    )
                }

                // 3. Salva a sessão persistente de forma segura
                sessionManager.setAuthenticated(
                    user = profile,
                    accessToken = accessToken,
                    refreshToken = refreshToken
                )

                Log.d(TAG, "Sessão CIADI+ salva com sucesso para ${profile.fullName} (${profile.role})")
                return@withContext Result.success(profile)
            } else {
                val rawError = response.errorBody()?.string() ?: ""
                Log.w(TAG, "Erro HTTP ${response.code()} do Supabase Auth: $rawError")

                val errorMessage = when (response.code()) {
                    400 -> {
                        when {
                            rawError.contains("invalid_credentials", ignoreCase = true) ||
                            rawError.contains("Invalid login credentials", ignoreCase = true) ->
                                "Email ou palavra-passe incorretos."
                            rawError.contains("Email not confirmed", ignoreCase = true) ->
                                "Esta conta ainda precisa ser confirmada via e-mail."
                            else -> "Credenciais inválidas ou erro no formato da requisição (HTTP 400)."
                        }
                    }
                    401 -> "Não autorizado: verifique a chave pública ou credenciais."
                    403 -> "Acesso recusado pelo servidor de autenticação."
                    422 -> "Dados incompletos ou inválidos para login."
                    429 -> "Limite de tentativas excedido no Supabase. Aguarde alguns instantes."
                    in 500..599 -> "Servidor Supabase temporariamente indisponível. Tente novamente mais tarde."
                    else -> "Falha ao autenticar no Supabase (Código ${response.code()})."
                }

                return@withContext Result.failure(Exception(errorMessage))
            }
        } catch (e: java.net.UnknownHostException) {
            Log.e(TAG, "Falha de rede (DNS/Internet): ${e.message}")
            return@withContext Result.failure(
                Exception("Não foi possível ligar ao CIADI. Verifique a sua ligação à Internet.")
            )
        } catch (e: java.net.SocketTimeoutException) {
            Log.e(TAG, "Timeout de conexão: ${e.message}")
            return@withContext Result.failure(
                Exception("Tempo limite esgotado ao conectar ao Supabase CIADI. Tente novamente.")
            )
        } catch (e: Exception) {
            Log.e(TAG, "Erro inesperado no Auth: ${e.message}", e)
            return@withContext Result.failure(
                Exception("Erro de conexão ao Supabase Auth (${SupabaseConfig.supabaseUrl}): ${e.localizedMessage}")
            )
        }
    }

    private suspend fun fetchProfileFromDatabase(userId: String, fallbackEmail: String, accessToken: String): UserProfile? {
        try {
            val response = clientFactory.restApi.getPerfis(
                authHeader = "Bearer $accessToken",
                idFilter = "eq.$userId"
            )
            if (response.isSuccessful && !response.body().isNullOrEmpty()) {
                val p = response.body()!!.first()
                val role = UserRole.fromCode(p.tipo)
                return UserProfile(
                    id = p.id,
                    email = p.email ?: fallbackEmail,
                    fullName = p.nomeCompleto ?: p.nomeExibicao ?: fallbackEmail.substringBefore("@"),
                    role = role,
                    specialty = p.funcaoAt,
                    unitName = p.unidadeNome ?: "CIADI — Centro Integrado",
                    permissions = Permission.defaultPermissionsFor(role)
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "Não foi possível carregar tabela 'perfis' para $userId: ${e.message}")
        }
        return null
    }

    override suspend fun refreshSession(): Result<UserProfile> = withContext(Dispatchers.IO) {
        val currentRefreshToken = sessionManager.getCurrentRefreshToken()
        if (currentRefreshToken.isNullOrBlank()) {
            return@withContext Result.failure(Exception("Nenhum refresh token disponível."))
        }

        try {
            val response = clientFactory.authApi.refreshToken(
                request = SupabaseRefreshTokenRequest(refreshToken = currentRefreshToken)
            )

            if (response.isSuccessful) {
                val body = response.body()
                val newAccessToken = body?.accessToken.orEmpty()
                val newRefreshToken = body?.refreshToken.orEmpty()

                if (newAccessToken.isNotBlank()) {
                    sessionManager.updateTokens(newAccessToken, newRefreshToken)
                    val currentUser = (sessionManager.sessionFlow.value as? UserSession.Authenticated)?.user
                    if (currentUser != null) {
                        return@withContext Result.success(currentUser)
                    }
                }
            }
            Result.failure(Exception("Falha ao renovar token com Supabase."))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun signOut(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.getCurrentAccessToken()
            if (!token.isNullOrBlank()) {
                clientFactory.authApi.logout("Bearer $token")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Logout no Supabase remoto falhou: ${e.message}")
        }
        sessionManager.clearSession()
        Result.success(Unit)
    }

    override suspend fun requestPasswordReset(email: String): Result<Unit> = withContext(Dispatchers.IO) {
        val trimmed = email.trim()
        if (trimmed.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Informe o e-mail cadastrado."))
        }
        try {
            val resp = clientFactory.authApi.recoverPassword(SupabaseResetPasswordRequest(email = trimmed))
            if (resp.isSuccessful) {
                return@withContext Result.success(Unit)
            } else {
                return@withContext Result.failure(Exception("Erro na recuperação (HTTP ${resp.code()})"))
            }
        } catch (e: Exception) {
            return@withContext Result.failure(e)
        }
    }

    override fun getSupabaseStatus(): SupabaseStatus {
        val configured = clientFactory.isReadyForConnection()
        return SupabaseStatus(
            url = clientFactory.getBaseUrl(),
            isConfigured = configured,
            isConnected = configured,
            rlsEnforced = true,
            statusMessage = if (configured) {
                "Conectado ao Supabase Oficial CIADI (RLS Ativo)"
            } else {
                "Conectado à URL oficial CIADI — RLS ativo no PostgreSQL"
            }
        )
    }

    override fun switchRoleForPreview(role: UserRole) {
        sessionManager.switchRoleForPreview(role)
    }
}

