package com.example.data.remote.api

import com.example.data.remote.dto.AgendamentoDto
import com.example.data.remote.dto.AtIncidenteDto
import com.example.data.remote.dto.AtRegistoObjetivoDto
import com.example.data.remote.dto.AtSessaoDto
import com.example.data.remote.dto.AtSupervisaoDto
import com.example.data.remote.dto.AtribuicaoAtDto
import com.example.data.remote.dto.ChatGrupoDto
import com.example.data.remote.dto.ChatMensagemDto
import com.example.data.remote.dto.DocumentoClinicoDto
import com.example.data.remote.dto.EspecialidadeDto
import com.example.data.remote.dto.FormularioClinicoDto
import com.example.data.remote.dto.NotificacaoDto
import com.example.data.remote.dto.PacienteDto
import com.example.data.remote.dto.PerfilDto
import com.example.data.remote.dto.ProfissionalDto
import com.example.data.remote.dto.VinculoFamiliarDto
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.QueryMap

/**
 * Interface Retrofit oficial para as tabelas do PostgreSQL no Supabase do CIADI.
 *
 * Todas as chamadas para esta interface passam pelo SupabaseAuthInterceptor,
 * transmitindo o token JWT no cabeçalho Authorization.
 * A segurança e filtragem é garantida pelo Row Level Security (RLS) do PostgreSQL.
 */
interface SupabaseRestApi {

    // --- 1. Perfis (tabela: perfis) ---
    @GET("rest/v1/perfis")
    suspend fun getPerfis(
        @Header("Authorization") authHeader: String? = null,
        @Query("select") select: String = "*",
        @Query("id") idFilter: String? = null
    ): Response<List<PerfilDto>>

    // --- 2. Pacientes / Crianças (tabela: pacientes) ---
    @GET("rest/v1/pacientes")
    suspend fun getPacientes(
        @Query("select") select: String = "*",
        @Query("id") idFilter: String? = null,
        @Query("order") order: String = "nome.asc"
    ): Response<List<PacienteDto>>

    // --- 3. Vínculos Familiares (tabela: ciadi_vinculos_familiares) ---
    @GET("rest/v1/ciadi_vinculos_familiares")
    suspend fun getVinculosFamiliares(
        @Query("select") select: String = "*,pacientes(*)",
        @Query("perfil_id") perfilIdFilter: String? = null
    ): Response<List<VinculoFamiliarDto>>

    // --- 4. Atribuições de A.T. (tabela: ciadi_atribuicoes_at) ---
    @GET("rest/v1/ciadi_atribuicoes_at")
    suspend fun getAtribuicoesAt(
        @Query("select") select: String = "*,pacientes(*)",
        @Query("profissional_id") profissionalIdFilter: String? = null,
        @Query("ativo") ativoFilter: String? = "eq.true"
    ): Response<List<AtribuicaoAtDto>>

    // --- 5. Sessões de A.T. (tabela: ciadi_at_sessoes) ---
    @GET("rest/v1/ciadi_at_sessoes")
    suspend fun getAtSessoes(
        @Query("select") select: String = "*",
        @Query("atribuicao_id") atribuicaoIdFilter: String? = null,
        @Query("order") order: String = "data_sessao.desc"
    ): Response<List<AtSessaoDto>>

    @POST("rest/v1/ciadi_at_sessoes")
    suspend fun createAtSessao(
        @Body sessao: AtSessaoDto
    ): Response<List<AtSessaoDto>>

    // --- 6. Registros de Objetivos do P.E.I. em Sessão (tabela: ciadi_at_registos_objetivos) ---
    @GET("rest/v1/ciadi_at_registos_objetivos")
    suspend fun getAtRegistosObjetivos(
        @Query("select") select: String = "*",
        @Query("sessao_id") sessaoIdFilter: String? = null
    ): Response<List<AtRegistoObjetivoDto>>

    @POST("rest/v1/ciadi_at_registos_objetivos")
    suspend fun createAtRegistoObjetivo(
        @Body registro: AtRegistoObjetivoDto
    ): Response<List<AtRegistoObjetivoDto>>

    // --- 7. Incidentes e Ocorrências de A.T. (tabela: ciadi_at_incidentes) ---
    @GET("rest/v1/ciadi_at_incidentes")
    suspend fun getAtIncidentes(
        @Query("select") select: String = "*",
        @Query("sessao_id") sessaoIdFilter: String? = null,
        @Query("order") order: String = "criado_em.desc"
    ): Response<List<AtIncidenteDto>>

    @POST("rest/v1/ciadi_at_incidentes")
    suspend fun createAtIncidente(
        @Body incidente: AtIncidenteDto
    ): Response<List<AtIncidenteDto>>

    // --- 8. Supervisões de A.T. (tabela: ciadi_at_supervisoes) ---
    @GET("rest/v1/ciadi_at_supervisoes")
    suspend fun getAtSupervisoes(
        @Query("select") select: String = "*",
        @Query("profissional_at_id") profissionalAtIdFilter: String? = null,
        @Query("order") order: String = "data_supervisao.desc"
    ): Response<List<AtSupervisaoDto>>

    // --- 9. Profissionais (tabela: profissionais) ---
    @GET("rest/v1/profissionais")
    suspend fun getProfissionais(
        @Query("select") select: String = "*",
        @Query("order") order: String = "nome_completo.asc"
    ): Response<List<ProfissionalDto>>

    // --- 10. Agenda / Agendamentos (tabela: agendamentos) ---
    @GET("rest/v1/agendamentos")
    suspend fun getAgendamentos(
        @Query("select") select: String = "*",
        @Query("paciente_id") pacienteIdFilter: String? = null,
        @Query("profissional_id") profissionalIdFilter: String? = null,
        @Query("order") order: String = "data_hora.asc"
    ): Response<List<AgendamentoDto>>

    @POST("rest/v1/agendamentos")
    suspend fun createAgendamento(
        @Body agendamento: AgendamentoDto
    ): Response<List<AgendamentoDto>>

    // --- 11. Especialidades (tabela: especialidades) ---
    @GET("rest/v1/especialidades")
    suspend fun getEspecialidades(
        @Query("select") select: String = "*",
        @Query("ativo") ativoFilter: String? = "eq.true"
    ): Response<List<EspecialidadeDto>>

    // --- 12. Formulários Clínicos (tabela: ciadi_formularios_clinicos) ---
    @GET("rest/v1/ciadi_formularios_clinicos")
    suspend fun getFormulariosClinicos(
        @Query("select") select: String = "*",
        @Query("ativo") ativoFilter: String? = "eq.true",
        @Query("order") order: String = "titulo.asc"
    ): Response<List<FormularioClinicoDto>>

    // --- 13. Documentos Clínicos / Laudos / P.E.I. (tabela: documentos_clinicos) ---
    @GET("rest/v1/documentos_clinicos")
    suspend fun getDocumentosClinicos(
        @Query("select") select: String = "*",
        @Query("paciente_id") pacienteIdFilter: String? = null,
        @Query("estado") estadoFilter: String? = null,
        @Query("order") order: String = "criado_em.desc"
    ): Response<List<DocumentoClinicoDto>>

    @POST("rest/v1/documentos_clinicos")
    suspend fun createDocumentoClinico(
        @Body documento: DocumentoClinicoDto
    ): Response<List<DocumentoClinicoDto>>

    // --- 13.1 Histórico de Documentos (tabela: ciadi_documentos_clinicos_historico) ---
    @GET("rest/v1/ciadi_documentos_clinicos_historico")
    suspend fun getDocumentoHistorico(
        @Query("select") select: String = "*",
        @Query("documento_id") documentoIdFilter: String? = null,
        @Query("order") order: String = "data_registro.desc"
    ): Response<List<com.example.data.remote.dto.DocumentoHistoricoDto>>

    // --- 14. Chat: Grupos (tabela: ciadi_chat_grupos) ---
    @GET("rest/v1/ciadi_chat_grupos")
    suspend fun getChatGrupos(
        @Query("select") select: String = "*",
        @Query("order") order: String = "criado_em.desc"
    ): Response<List<ChatGrupoDto>>

    // --- 15. Chat: Mensagens (tabela: ciadi_chat_mensagens) ---
    @GET("rest/v1/ciadi_chat_mensagens")
    suspend fun getChatMensagens(
        @Query("select") select: String = "*",
        @Query("grupo_id") grupoIdFilter: String? = null,
        @Query("order") order: String = "criado_em.asc"
    ): Response<List<ChatMensagemDto>>

    @POST("rest/v1/ciadi_chat_mensagens")
    suspend fun sendChatMensagem(
        @Body mensagem: ChatMensagemDto
    ): Response<List<ChatMensagemDto>>

    // --- 16. Notificações (tabela: notificacoes) ---
    @GET("rest/v1/notificacoes")
    suspend fun getNotificacoes(
        @Query("select") select: String = "*",
        @Query("order") order: String = "criado_em.desc"
    ): Response<List<NotificacaoDto>>

    @PATCH("rest/v1/notificacoes")
    suspend fun markNotificacaoRead(
        @Query("id") idFilter: String,
        @Body body: Map<String, Boolean>
    ): Response<List<NotificacaoDto>>

    // --- 17. SOS CIADI+ (RPC: ciadi_criar_alerta_sos) ---
    @POST("rest/v1/rpc/ciadi_criar_alerta_sos")
    suspend fun criarAlertaSos(
        @Body request: com.example.data.remote.dto.CriarAlertaSosRequest
    ): Response<okhttp3.ResponseBody>

    // --- 18. Agenda Autorizada do Portal (RPC: ciadi_portal_agendamentos_autorizados) ---
    @POST("rest/v1/rpc/ciadi_portal_agendamentos_autorizados")
    suspend fun getPortalAgendamentosAutorizados(
        @Body body: Map<String, String>
    ): Response<List<com.example.data.remote.dto.PortalAgendamentoDto>>

    // --- 19. Clínica Virtual (RPCs de Vídeo) ---
    @POST("rest/v1/rpc/ciadi_preparar_sala_video")
    suspend fun prepararSalaVideo(
        @Body request: com.example.data.remote.dto.VideoSalaRequest
    ): Response<okhttp3.ResponseBody>

    @POST("rest/v1/rpc/ciadi_registrar_entrada_video")
    suspend fun registrarEntradaVideo(
        @Body request: com.example.data.remote.dto.VideoSalaRequest
    ): Response<okhttp3.ResponseBody>

    @POST("rest/v1/rpc/ciadi_registrar_saida_video")
    suspend fun registrarSaidaVideo(
        @Body request: com.example.data.remote.dto.VideoSalaRequest
    ): Response<okhttp3.ResponseBody>

    @POST("rest/v1/rpc/ciadi_encerrar_sala_video")
    suspend fun encerrarSalaVideo(
        @Body request: com.example.data.remote.dto.VideoSalaRequest
    ): Response<okhttp3.ResponseBody>

    // --- Consulta genérica com RLS ---
    @GET("rest/v1/{table}")
    suspend fun queryTable(
        @Path("table") table: String,
        @QueryMap filters: Map<String, String>
    ): Response<okhttp3.ResponseBody>
}
