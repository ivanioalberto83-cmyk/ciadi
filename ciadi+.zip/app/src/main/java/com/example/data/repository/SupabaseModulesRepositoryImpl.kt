package com.example.data.repository

import com.example.core.config.SupabaseConfig
import com.example.core.network.SupabaseErrorHandler
import com.example.core.session.SessionManager
import com.example.data.remote.client.SupabaseClientFactory
import com.example.data.remote.dto.AgendamentoDto
import com.example.data.remote.dto.AtIncidenteDto
import com.example.data.remote.dto.AtRegistoObjetivoDto
import com.example.data.remote.dto.AtSessaoDto
import com.example.data.remote.dto.AtSupervisaoDto
import com.example.data.remote.dto.AtribuicaoAtDto
import com.example.data.remote.dto.ChatGrupoDto
import com.example.data.remote.dto.ChatMensagemDto
import com.example.data.remote.dto.DocumentoClinicoDto
import com.example.data.remote.dto.DocumentoHistoricoDto
import com.example.data.remote.dto.FormularioClinicoDto
import com.example.data.remote.dto.NotificacaoDto
import com.example.data.remote.dto.PacienteDto
import com.example.data.remote.dto.PerfilDto
import com.example.data.remote.dto.VinculoFamiliarDto
import com.example.domain.repository.ATRepository
import com.example.domain.repository.AgendaRepository
import com.example.domain.repository.ChatRepository
import com.example.domain.repository.ClinicalDocumentsRepository
import com.example.domain.repository.ClinicalFormsRepository
import com.example.domain.repository.FamilyRepository
import com.example.domain.repository.ModulesRepository
import com.example.domain.repository.NotificationsRepository
import com.example.domain.repository.ProfileRepository
import com.example.domain.repository.SosRepository
import com.example.data.remote.dto.PortalAgendamentoDto
import com.example.data.remote.dto.SosAlertaResultDto
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

/**
 * Implementação real dos módulos do CIADI conectada ao PostgreSQL do Supabase via PostgREST.
 *
 * Implementa tanto a interface agregada ModulesRepository quanto as interfaces especializadas
 * (FamilyRepository, ATRepository, AgendaRepository, ClinicalFormsRepository, ClinicalDocumentsRepository,
 * ChatRepository, NotificationsRepository, ProfileRepository).
 *
 * Todas as requisições utilizam o token JWT do usuário ativo (injetado pelo SupabaseAuthInterceptor),
 * de modo que o RLS filtre no próprio banco de dados as linhas correspondentes a cada perfil.
 */
class SupabaseModulesRepositoryImpl(
    private val sessionManager: SessionManager,
    private val clientFactory: SupabaseClientFactory = SupabaseClientFactory(sessionManager)
) : ModulesRepository,
    FamilyRepository,
    ATRepository,
    AgendaRepository,
    ClinicalFormsRepository,
    ClinicalDocumentsRepository,
    ChatRepository,
    NotificationsRepository,
    ProfileRepository,
    SosRepository {

    private val _vinculosFamiliares = MutableStateFlow<List<VinculoFamiliarDto>>(emptyList())
    private val _pacientes = MutableStateFlow<List<PacienteDto>>(emptyList())
    private val _selectedPatient = MutableStateFlow<PacienteDto?>(null)

    private val _atribuicoesAt = MutableStateFlow<List<AtribuicaoAtDto>>(emptyList())
    private val _atSessoes = MutableStateFlow<List<AtSessaoDto>>(emptyList())
    private val _atRegistosObjetivos = MutableStateFlow<List<AtRegistoObjetivoDto>>(emptyList())
    private val _atIncidentes = MutableStateFlow<List<AtIncidenteDto>>(emptyList())
    private val _atSupervisoes = MutableStateFlow<List<AtSupervisaoDto>>(emptyList())

    private val _agendamentos = MutableStateFlow<List<AgendamentoDto>>(emptyList())
    private val _portalAgendamentos = MutableStateFlow<List<PortalAgendamentoDto>>(emptyList())
    private val _formulariosClinicos = MutableStateFlow<List<FormularioClinicoDto>>(emptyList())
    private val _documentosClinicos = MutableStateFlow<List<DocumentoClinicoDto>>(emptyList())

    private val _chatGrupos = MutableStateFlow<List<ChatGrupoDto>>(emptyList())
    private val _chatMensagens = MutableStateFlow<Map<String, List<ChatMensagemDto>>>(emptyMap())
    private val _notificacoes = MutableStateFlow<List<NotificacaoDto>>(emptyList())
    private val _currentProfile = MutableStateFlow<PerfilDto?>(null)

    // --- ModulesRepository / FamilyRepository Impl ---
    override fun observeCriancasVinculadas(): Flow<List<VinculoFamiliarDto>> = _vinculosFamiliares.asStateFlow()
    override fun observePacientes(): Flow<List<PacienteDto>> = _pacientes.asStateFlow()

    override fun observeVinculos(): StateFlow<List<VinculoFamiliarDto>> = _vinculosFamiliares.asStateFlow()
    override fun observeAuthorizedPatients(): StateFlow<List<PacienteDto>> = _pacientes.asStateFlow()
    override fun observeSelectedPatient(): StateFlow<PacienteDto?> = _selectedPatient.asStateFlow()

    override fun selectPatient(patient: PacienteDto) {
        _selectedPatient.value = patient
    }

    override suspend fun syncFamilyBonds(): Result<Unit> = sincronizarTabela(SupabaseConfig.Tables.VINCULOS_FAMILIARES)

    // --- ATRepository Impl ---
    override fun observeAtribuicoesAt(): Flow<List<AtribuicaoAtDto>> = _atribuicoesAt.asStateFlow()
    override fun observeAtSessoes(atribuicaoId: String?): Flow<List<AtSessaoDto>> = _atSessoes.asStateFlow()
    override fun observeAtRegistosObjetivos(sessaoId: String?): Flow<List<AtRegistoObjetivoDto>> = _atRegistosObjetivos.asStateFlow()
    override fun observeAtIncidentes(sessaoId: String?): Flow<List<AtIncidenteDto>> = _atIncidentes.asStateFlow()
    override fun observeAtSupervisoes(): Flow<List<AtSupervisaoDto>> = _atSupervisoes.asStateFlow()

    override fun observeAtribuicoes(): StateFlow<List<AtribuicaoAtDto>> = _atribuicoesAt.asStateFlow()
    override fun observeSessoes(): StateFlow<List<AtSessaoDto>> = _atSessoes.asStateFlow()
    override fun observeRegistosObjetivos(): StateFlow<List<AtRegistoObjetivoDto>> = _atRegistosObjetivos.asStateFlow()
    override fun observeIncidentes(): StateFlow<List<AtIncidenteDto>> = _atIncidentes.asStateFlow()
    override fun observeSupervisoes(): StateFlow<List<AtSupervisaoDto>> = _atSupervisoes.asStateFlow()

    override suspend fun registrarSessao(sessao: AtSessaoDto): Result<AtSessaoDto> = registrarSessaoAt(sessao)
    override suspend fun registrarObjetivo(objetivo: AtRegistoObjetivoDto): Result<AtRegistoObjetivoDto> = registrarObjetivoAt(objetivo)
    override suspend fun registrarIncidente(incidente: AtIncidenteDto): Result<AtIncidenteDto> = registrarIncidenteAt(incidente)
    override suspend fun syncATData(): Result<Unit> = sincronizarTabela(SupabaseConfig.Tables.AT_SESSOES)

    override suspend fun registrarSessaoAt(sessao: AtSessaoDto): Result<AtSessaoDto> = withContext(Dispatchers.IO) {
        if (!clientFactory.isReadyForConnection()) {
            return@withContext Result.failure(IllegalStateException("Supabase não configurado."))
        }
        try {
            val response = clientFactory.restApi.createAtSessao(sessao)
            if (response.isSuccessful && !response.body().isNullOrEmpty()) {
                val created = response.body()!!.first()
                _atSessoes.value = listOf(created) + _atSessoes.value
                Result.success(created)
            } else {
                val errorMsg = SupabaseErrorHandler.parseHttpErrorMessage(response.code())
                Result.failure(Exception(errorMsg))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun registrarIncidenteAt(incidente: AtIncidenteDto): Result<AtIncidenteDto> = withContext(Dispatchers.IO) {
        if (!clientFactory.isReadyForConnection()) {
            return@withContext Result.failure(IllegalStateException("Supabase não configurado."))
        }
        try {
            val response = clientFactory.restApi.createAtIncidente(incidente)
            if (response.isSuccessful && !response.body().isNullOrEmpty()) {
                val created = response.body()!!.first()
                _atIncidentes.value = listOf(created) + _atIncidentes.value
                Result.success(created)
            } else {
                val errorMsg = SupabaseErrorHandler.parseHttpErrorMessage(response.code())
                Result.failure(Exception(errorMsg))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun registrarObjetivoAt(registro: AtRegistoObjetivoDto): Result<AtRegistoObjetivoDto> = withContext(Dispatchers.IO) {
        if (!clientFactory.isReadyForConnection()) {
            return@withContext Result.failure(IllegalStateException("Supabase não configurado."))
        }
        try {
            val response = clientFactory.restApi.createAtRegistoObjetivo(registro)
            if (response.isSuccessful && !response.body().isNullOrEmpty()) {
                val created = response.body()!!.first()
                _atRegistosObjetivos.value = listOf(created) + _atRegistosObjetivos.value
                Result.success(created)
            } else {
                val errorMsg = SupabaseErrorHandler.parseHttpErrorMessage(response.code())
                Result.failure(Exception(errorMsg))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- AgendaRepository Impl ---
    override fun observeAgendamentos(pacienteId: String?, profissionalId: String?): Flow<List<AgendamentoDto>> = _agendamentos.asStateFlow()
    override fun observeAgendamentos(): StateFlow<List<AgendamentoDto>> = _agendamentos.asStateFlow()
    override fun observePortalAgendamentos(): StateFlow<List<PortalAgendamentoDto>> = _portalAgendamentos.asStateFlow()

    override suspend fun fetchPortalAgendamentos(pacienteId: String?): Result<List<PortalAgendamentoDto>> = withContext(Dispatchers.IO) {
        if (!clientFactory.isReadyForConnection()) {
            return@withContext Result.failure(IllegalStateException("Supabase não configurado."))
        }
        try {
            val body = if (pacienteId != null) mapOf("p_paciente_id" to pacienteId) else emptyMap()
            val resp = clientFactory.restApi.getPortalAgendamentosAutorizados(body)
            if (resp.isSuccessful) {
                val lista = resp.body().orEmpty()
                _portalAgendamentos.value = lista
                Result.success(lista)
            } else {
                // Fallback gracioso para a tabela regular agendamentos
                val regularResp = clientFactory.restApi.getAgendamentos(pacienteIdFilter = pacienteId?.let { "eq.$it" })
                if (regularResp.isSuccessful) {
                    val fallbackList = regularResp.body().orEmpty().map { a ->
                        PortalAgendamentoDto(
                            id = a.id,
                            paciente = a.pacienteNome,
                            pacienteId = a.pacienteId,
                            profissional = a.profissionalNome,
                            profissionalId = a.profissionalId,
                            especialidade = a.especialidadeNome,
                            dataHora = a.dataHora,
                            duracao = a.duracaoMinutos,
                            tipo = a.tipo ?: "Consulta",
                            modalidade = a.modalidade ?: "Presencial",
                            estado = a.estado ?: "agendada",
                            motivo = a.motivo,
                            observacoes = a.observacoes,
                            linkVideo = a.linkVideo,
                            salaNome = a.salaNome
                        )
                    }
                    _portalAgendamentos.value = fallbackList
                    Result.success(fallbackList)
                } else {
                    val errorMsg = SupabaseErrorHandler.parseHttpErrorMessage(resp.code())
                    Result.failure(Exception(errorMsg))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun syncAgenda(): Result<Unit> = sincronizarTabela(SupabaseConfig.Tables.AGENDAMENTOS)

    override suspend fun criarAgendamento(agendamento: AgendamentoDto): Result<AgendamentoDto> = withContext(Dispatchers.IO) {
        if (!clientFactory.isReadyForConnection()) {
            return@withContext Result.failure(IllegalStateException("Supabase não configurado."))
        }
        try {
            val response = clientFactory.restApi.createAgendamento(agendamento)
            if (response.isSuccessful && !response.body().isNullOrEmpty()) {
                val created = response.body()!!.first()
                _agendamentos.value = _agendamentos.value + created
                Result.success(created)
            } else {
                val errorMsg = SupabaseErrorHandler.parseHttpErrorMessage(response.code())
                Result.failure(Exception(errorMsg))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- Clínica Virtual (RPCs de Vídeo) ---
    override suspend fun prepararSalaVideo(agendamentoId: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val resp = clientFactory.restApi.prepararSalaVideo(com.example.data.remote.dto.VideoSalaRequest(agendamentoId))
            if (resp.isSuccessful) {
                Result.success("sala-$agendamentoId")
            } else {
                Result.failure(Exception(SupabaseErrorHandler.parseHttpErrorMessage(resp.code())))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun registrarEntradaVideo(agendamentoId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val resp = clientFactory.restApi.registrarEntradaVideo(com.example.data.remote.dto.VideoSalaRequest(agendamentoId))
            if (resp.isSuccessful) Result.success(Unit) else Result.failure(Exception(SupabaseErrorHandler.parseHttpErrorMessage(resp.code())))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun registrarSaidaVideo(agendamentoId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val resp = clientFactory.restApi.registrarSaidaVideo(com.example.data.remote.dto.VideoSalaRequest(agendamentoId))
            if (resp.isSuccessful) Result.success(Unit) else Result.failure(Exception(SupabaseErrorHandler.parseHttpErrorMessage(resp.code())))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun encerrarSalaVideo(agendamentoId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val resp = clientFactory.restApi.encerrarSalaVideo(com.example.data.remote.dto.VideoSalaRequest(agendamentoId))
            if (resp.isSuccessful) Result.success(Unit) else Result.failure(Exception(SupabaseErrorHandler.parseHttpErrorMessage(resp.code())))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- SosRepository Impl (RPC: ciadi_criar_alerta_sos) ---
    override suspend fun enviarAlertaSos(
        pacienteId: String,
        mensagem: String,
        latitude: Double?,
        longitude: Double?,
        localizacaoAutorizada: Boolean
    ): Result<SosAlertaResultDto> = withContext(Dispatchers.IO) {
        if (!clientFactory.isReadyForConnection()) {
            return@withContext Result.failure(IllegalStateException("Supabase não configurado."))
        }
        try {
            val req = com.example.data.remote.dto.CriarAlertaSosRequest(
                pacienteId = pacienteId,
                mensagem = mensagem,
                latitude = latitude,
                longitude = longitude,
                localizacaoAutorizada = localizacaoAutorizada
            )
            val resp = clientFactory.restApi.criarAlertaSos(req)
            if (resp.isSuccessful) {
                val protocoloGerado = "SOS-${System.currentTimeMillis() % 100000}"
                Result.success(
                    SosAlertaResultDto(
                        id = pacienteId,
                        sucesso = true,
                        mensagem = "Alerta transmitido à equipe responsável do CIADI.",
                        protocolo = protocoloGerado
                    )
                )
            } else {
                val errorMsg = SupabaseErrorHandler.parseHttpErrorMessage(resp.code())
                Result.failure(Exception(errorMsg))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- ClinicalFormsRepository Impl ---
    override fun observeFormulariosClinicos(): Flow<List<FormularioClinicoDto>> = _formulariosClinicos.asStateFlow()
    override fun observeFormularios(): StateFlow<List<FormularioClinicoDto>> = _formulariosClinicos.asStateFlow()
    override suspend fun syncFormularios(): Result<Unit> = sincronizarTabela(SupabaseConfig.Tables.FORMULARIOS_CLINICOS)

    // --- ClinicalDocumentsRepository Impl ---
    override fun observeDocumentosClinicos(pacienteId: String?): Flow<List<DocumentoClinicoDto>> = _documentosClinicos.asStateFlow()
    override fun observeDocumentos(): StateFlow<List<DocumentoClinicoDto>> = _documentosClinicos.asStateFlow()
    override suspend fun emitirDocumento(documento: DocumentoClinicoDto): Result<DocumentoClinicoDto> = emitirDocumentoClinico(documento)
    override suspend fun syncDocumentos(): Result<Unit> = sincronizarTabela(SupabaseConfig.Tables.DOCUMENTOS_CLINICOS)

    override suspend fun emitirDocumentoClinico(documento: DocumentoClinicoDto): Result<DocumentoClinicoDto> = withContext(Dispatchers.IO) {
        if (!clientFactory.isReadyForConnection()) {
            return@withContext Result.failure(IllegalStateException("Supabase não configurado."))
        }
        try {
            val response = clientFactory.restApi.createDocumentoClinico(documento)
            if (response.isSuccessful && !response.body().isNullOrEmpty()) {
                val created = response.body()!!.first()
                _documentosClinicos.value = listOf(created) + _documentosClinicos.value
                Result.success(created)
            } else {
                val errorMsg = SupabaseErrorHandler.parseHttpErrorMessage(response.code())
                Result.failure(Exception(errorMsg))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getHistoricoDocumento(documentoId: String): Result<List<DocumentoHistoricoDto>> = withContext(Dispatchers.IO) {
        if (!clientFactory.isReadyForConnection()) {
            return@withContext Result.failure(IllegalStateException("Supabase não configurado."))
        }
        try {
            val response = clientFactory.restApi.getDocumentoHistorico(documentoIdFilter = "eq.$documentoId")
            if (response.isSuccessful) {
                Result.success(response.body().orEmpty())
            } else {
                val errorMsg = SupabaseErrorHandler.parseHttpErrorMessage(response.code())
                Result.failure(Exception(errorMsg))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- ChatRepository Impl ---
    override fun observeChatGrupos(): Flow<List<ChatGrupoDto>> = _chatGrupos.asStateFlow()
    override fun observeGrupos(): StateFlow<List<ChatGrupoDto>> = _chatGrupos.asStateFlow()
    override fun observeChatMensagens(grupoId: String): Flow<List<ChatMensagemDto>> {
        val current = _chatMensagens.value[grupoId].orEmpty()
        return MutableStateFlow(current).asStateFlow()
    }
    override fun observeMensagens(grupoId: String): StateFlow<List<ChatMensagemDto>> {
        val current = _chatMensagens.value[grupoId].orEmpty()
        return MutableStateFlow(current).asStateFlow()
    }
    override suspend fun syncChat(): Result<Unit> = sincronizarTabela(SupabaseConfig.Tables.CHAT_GRUPOS)

    override suspend fun enviarMensagem(mensagem: ChatMensagemDto): Result<ChatMensagemDto> = withContext(Dispatchers.IO) {
        if (!clientFactory.isReadyForConnection()) {
            return@withContext Result.failure(IllegalStateException("Supabase não configurado."))
        }
        try {
            val response = clientFactory.restApi.sendChatMensagem(mensagem)
            if (response.isSuccessful && !response.body().isNullOrEmpty()) {
                val created = response.body()!!.first()
                val current = _chatMensagens.value[mensagem.grupoId].orEmpty()
                _chatMensagens.value = _chatMensagens.value + (mensagem.grupoId to (current + created))
                Result.success(created)
            } else {
                val errorMsg = SupabaseErrorHandler.parseHttpErrorMessage(response.code())
                Result.failure(Exception(errorMsg))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- NotificationsRepository Impl ---
    override fun observeNotificacoes(): StateFlow<List<NotificacaoDto>> = _notificacoes.asStateFlow()
    override suspend fun syncNotificacoes(): Result<Unit> = sincronizarTabela(SupabaseConfig.Tables.NOTIFICACOES)

    override suspend fun marcarNotificacaoLida(id: String): Result<Unit> = marcarLida(id)

    override suspend fun marcarLida(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        if (!clientFactory.isReadyForConnection()) return@withContext Result.success(Unit)
        try {
            clientFactory.restApi.markNotificacaoRead(id, mapOf("lida" to true))
            _notificacoes.value = _notificacoes.value.map {
                if (it.id == id) it.copy(lida = true) else it
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- ProfileRepository Impl ---
    override fun observeCurrentProfile(): StateFlow<PerfilDto?> = _currentProfile.asStateFlow()

    override suspend fun fetchProfile(userId: String): Result<PerfilDto> = withContext(Dispatchers.IO) {
        if (!clientFactory.isReadyForConnection()) {
            return@withContext Result.failure(IllegalStateException("Supabase não configurado."))
        }
        try {
            val response = clientFactory.restApi.getPerfis(idFilter = "eq.$userId")
            if (response.isSuccessful && !response.body().isNullOrEmpty()) {
                val perfil = response.body()!!.first()
                _currentProfile.value = perfil
                Result.success(perfil)
            } else {
                val errorMsg = SupabaseErrorHandler.parseHttpErrorMessage(response.code())
                Result.failure(Exception(errorMsg))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- Sincronização Geral com PostgREST ---
    override suspend fun sincronizarTabela(nomeTabela: String): Result<Unit> = withContext(Dispatchers.IO) {
        if (!clientFactory.isReadyForConnection()) {
            return@withContext Result.failure(
                IllegalStateException("Supabase aguardando Anon Key válida no arquivo .env")
            )
        }

        try {
            when (nomeTabela) {
                SupabaseConfig.Tables.VINCULOS_FAMILIARES -> {
                    val resp = clientFactory.restApi.getVinculosFamiliares()
                    if (resp.isSuccessful) {
                        val vinculos = resp.body().orEmpty()
                        _vinculosFamiliares.value = vinculos
                        val pacientesExtraidos = vinculos.mapNotNull { it.paciente }
                        _pacientes.value = pacientesExtraidos
                        // Regra CIADI+: Se houver exatamente 1 criança autorizada, apresenta diretamente.
                        // Se houver várias crianças, NÃO seleciona automaticamente para exigir confirmação do usuário.
                        if (pacientesExtraidos.size == 1) {
                            _selectedPatient.value = pacientesExtraidos.first()
                        } else if (pacientesExtraidos.isEmpty()) {
                            _selectedPatient.value = null
                        }
                        Result.success(Unit)
                    } else {
                        Result.failure(Exception(SupabaseErrorHandler.parseHttpErrorMessage(resp.code())))
                    }
                }
                SupabaseConfig.Tables.PACIENTES -> {
                    val resp = clientFactory.restApi.getPacientes()
                    if (resp.isSuccessful) {
                        _pacientes.value = resp.body().orEmpty()
                        Result.success(Unit)
                    } else {
                        Result.failure(Exception(SupabaseErrorHandler.parseHttpErrorMessage(resp.code())))
                    }
                }
                SupabaseConfig.Tables.ATRIBUICOES_AT -> {
                    val resp = clientFactory.restApi.getAtribuicoesAt()
                    if (resp.isSuccessful) {
                        _atribuicoesAt.value = resp.body().orEmpty()
                        Result.success(Unit)
                    } else {
                        Result.failure(Exception(SupabaseErrorHandler.parseHttpErrorMessage(resp.code())))
                    }
                }
                SupabaseConfig.Tables.AT_SESSOES -> {
                    val resp = clientFactory.restApi.getAtSessoes()
                    if (resp.isSuccessful) {
                        _atSessoes.value = resp.body().orEmpty()
                        Result.success(Unit)
                    } else {
                        Result.failure(Exception(SupabaseErrorHandler.parseHttpErrorMessage(resp.code())))
                    }
                }
                SupabaseConfig.Tables.AGENDAMENTOS -> {
                    val resp = clientFactory.restApi.getAgendamentos()
                    if (resp.isSuccessful) {
                        _agendamentos.value = resp.body().orEmpty()
                        Result.success(Unit)
                    } else {
                        Result.failure(Exception(SupabaseErrorHandler.parseHttpErrorMessage(resp.code())))
                    }
                }
                SupabaseConfig.Tables.FORMULARIOS_CLINICOS -> {
                    val resp = clientFactory.restApi.getFormulariosClinicos()
                    if (resp.isSuccessful) {
                        _formulariosClinicos.value = resp.body().orEmpty()
                        Result.success(Unit)
                    } else {
                        Result.failure(Exception(SupabaseErrorHandler.parseHttpErrorMessage(resp.code())))
                    }
                }
                SupabaseConfig.Tables.DOCUMENTOS_CLINICOS -> {
                    val resp = clientFactory.restApi.getDocumentosClinicos()
                    if (resp.isSuccessful) {
                        _documentosClinicos.value = resp.body().orEmpty()
                        Result.success(Unit)
                    } else {
                        Result.failure(Exception(SupabaseErrorHandler.parseHttpErrorMessage(resp.code())))
                    }
                }
                SupabaseConfig.Tables.CHAT_GRUPOS -> {
                    val resp = clientFactory.restApi.getChatGrupos()
                    if (resp.isSuccessful) {
                        _chatGrupos.value = resp.body().orEmpty()
                        Result.success(Unit)
                    } else {
                        Result.failure(Exception(SupabaseErrorHandler.parseHttpErrorMessage(resp.code())))
                    }
                }
                SupabaseConfig.Tables.NOTIFICACOES -> {
                    val resp = clientFactory.restApi.getNotificacoes()
                    if (resp.isSuccessful) {
                        _notificacoes.value = resp.body().orEmpty()
                        Result.success(Unit)
                    } else {
                        Result.failure(Exception(SupabaseErrorHandler.parseHttpErrorMessage(resp.code())))
                    }
                }
                else -> Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
