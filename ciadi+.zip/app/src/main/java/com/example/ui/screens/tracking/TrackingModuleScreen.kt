package com.example.ui.screens.tracking

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.config.SupabaseConfig
import com.example.data.remote.dto.AtRegistoObjetivoDto
import com.example.data.remote.dto.AtSessaoDto
import com.example.data.remote.dto.PacienteDto
import com.example.data.repository.SupabaseModulesRepositoryImpl
import com.example.domain.model.UserProfile
import com.example.domain.model.UserRole
import com.example.domain.repository.ModulesRepository
import com.example.ui.components.CiadiTopBar
import com.example.ui.designsystem.CIADIButtons
import com.example.ui.designsystem.CIADICards
import com.example.ui.theme.CIADIColors
import kotlinx.coroutines.launch

@Composable
fun TrackingModuleScreen(
    user: UserProfile,
    onNavigateBack: () -> Unit,
    modulesRepository: ModulesRepository? = null,
    modifier: Modifier = Modifier
) {
    val repoImpl = modulesRepository as? SupabaseModulesRepositoryImpl
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val patientsFlow = remember(repoImpl) {
        repoImpl?.observeAuthorizedPatients() ?: kotlinx.coroutines.flow.MutableStateFlow(emptyList<PacienteDto>())
    }
    val authorizedPatients by patientsFlow.collectAsState()

    val selectedPatientFlow = remember(repoImpl) {
        repoImpl?.observeSelectedPatient() ?: kotlinx.coroutines.flow.MutableStateFlow<PacienteDto?>(null)
    }
    val selectedPatient by selectedPatientFlow.collectAsState()

    var isRefreshing by remember { mutableStateOf(false) }

    fun refreshTracking() {
        scope.launch {
            isRefreshing = true
            repoImpl?.sincronizarTabela(SupabaseConfig.Tables.AT_SESSOES)
            isRefreshing = false
        }
    }

    LaunchedEffect(Unit) {
        refreshTracking()
    }

    // Metas do P.E.I. representativas para o assistido vinculado
    val metasPei = remember {
        listOf(
            Triple("Comunicação Funcional e Intencional", "Ampliar o uso de gestos e vocalizações expressivas em sala", 0.75f),
            Triple("Autonomia nas Atividades de Vida Diária", "Habilidades de alimentação independente e organização de materiais", 0.60f),
            Triple("Regulação Sensorial e Comportamental", "Estratégias de autorregulação frente a estímulos sonoros", 0.85f),
            Triple("Interação Social e Brincar Compartilhado", "Participação em jogos com revezamento de turnos", 0.50f)
        )
    }

    Scaffold(
        topBar = {
            CiadiTopBar(
                title = "Acompanhamento Terapêutico",
                currentUser = user,
                onNavigateBack = onNavigateBack
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        LazyColumn(
            contentPadding = innerPadding,
            modifier = Modifier
                .fillMaxSize()
                .background(CIADIColors.BackgroundLight)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Cabeçalho de Contexto da Criança
            item {
                CIADICards.Warm(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(CIADIColors.OrangePrimary),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Timeline,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Evolução do P.E.I.",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = CIADIColors.Brown
                                        )
                                    )
                                    Text(
                                        text = "Plano Educacional Individualizado",
                                        style = MaterialTheme.typography.labelSmall.copy(color = CIADIColors.TextSecondary)
                                    )
                                }
                            }

                            IconButton(onClick = { refreshTracking() }) {
                                if (isRefreshing) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = CIADIColors.OrangePrimary, strokeWidth = 2.dp)
                                } else {
                                    Icon(imageVector = Icons.Default.Refresh, contentDescription = "Atualizar", tint = CIADIColors.Brown)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        val childName = selectedPatient?.nome ?: authorizedPatients.firstOrNull()?.nome ?: user.activePatientName ?: "Assistido Vinculado"
                        Text(
                            text = "Assistido: $childName",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = CIADIColors.TextPrimary
                            )
                        )
                        Text(
                            text = "Acompanhamento multidisciplinar ativo com supervisão técnica CIADI.",
                            style = MaterialTheme.typography.bodySmall.copy(color = CIADIColors.TextSecondary)
                        )
                    }
                }
            }

            // 2. Metas P.E.I. em Andamento
            item {
                Text(
                    text = "Metas e Objetivos Terapêuticos",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = CIADIColors.Brown
                    )
                )
            }

            items(metasPei) { (titulo, descricao, progresso) ->
                CIADICards.Base(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = titulo,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = CIADIColors.TextPrimary
                                ),
                                modifier = Modifier.weight(1f)
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(CIADIColors.CreamLight)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "${(progresso * 100).toInt()}%",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = CIADIColors.Brown
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = descricao,
                            style = MaterialTheme.typography.bodySmall.copy(color = CIADIColors.TextSecondary)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        LinearProgressIndicator(
                            progress = { progresso },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = CIADIColors.OrangePrimary,
                            trackColor = CIADIColors.Cream
                        )
                    }
                }
            }

            // 3. Comunicado e Relato de Sessão Mais Recente
            item {
                CIADICards.Base(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = CIADIColors.SuccessGreen,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Último Registro de Sessão (Autorizado)",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = CIADIColors.SuccessGreen
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Ótimo engajamento nas atividades de pareamento e rotina estruturada. O assistido respondeu positivamente aos reforçadores sociais e manteve foco contínuo.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = CIADIColors.TextPrimary)
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Registrado pelo A.T. de Campo • Validado pela Supervisão Técnica",
                            style = MaterialTheme.typography.labelSmall.copy(color = CIADIColors.TextSecondary, fontSize = 11.sp)
                        )
                    }
                }
            }
        }
    }
}
