package com.example.ui.screens.chat

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.remote.dto.ChatGrupoDto
import com.example.data.remote.dto.ChatMensagemDto
import com.example.domain.model.UserProfile
import com.example.domain.repository.ModulesRepository
import com.example.ui.theme.CIADIColors
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatModuleScreen(
    user: UserProfile,
    onNavigateBack: () -> Unit,
    modulesRepository: ModulesRepository? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val gruposList by (modulesRepository?.observeChatGrupos()
        ?.collectAsState(initial = emptyList())
        ?: remember { mutableStateOf(emptyList<ChatGrupoDto>()) })

    var selectedGroup by remember {
        mutableStateOf(
            ChatGrupoDto(
                id = "grupo_familia_equipa",
                nome = "Equipe Multidisciplinar — ${user.activePatientName ?: "Assistido"}",
                tipo = "familia_equipa",
                pacienteNome = user.activePatientName ?: "Lucas Silva"
            )
        )
    }

    var messageInput by remember { mutableStateOf("") }
    var showAttachmentSheet by remember { mutableStateOf(false) }
    var showOptionsMenu by remember { mutableStateOf(false) }

    // Mensagens locais/reativas para a conversa selecionada
    val localMessages = remember {
        mutableListOf(
            ChatMensagemDto(
                id = "1",
                grupoId = selectedGroup.id,
                autorId = "coord",
                autorNome = "Coordenação CIADI",
                conteudo = "Olá! Este é o canal seguro oficial de comunicação entre família e equipe terapêutica do CIADI.",
                lida = true,
                criadoEm = "Hoje, 09:00"
            ),
            ChatMensagemDto(
                id = "2",
                grupoId = selectedGroup.id,
                autorId = "at",
                autorNome = "A.T. Gabriel",
                conteudo = "Sessão de campo realizada com sucesso na escola. Objetivos de autonomia social foram estimulados.",
                lida = true,
                criadoEm = "Hoje, 11:30"
            )
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(selectedGroup.nome, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text(
                            text = "Canal Seguro RLS • ${selectedGroup.tipo}",
                            fontSize = 11.sp,
                            color = CIADIColors.TealPrimary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                },
                actions = {
                    IconButton(onClick = { showOptionsMenu = true }) {
                        Icon(imageVector = Icons.Default.MoreVert, contentDescription = "Opções")
                    }
                    DropdownMenu(
                        expanded = showOptionsMenu,
                        onDismissRequest = { showOptionsMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Enviar pelo WhatsApp") },
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.Share, contentDescription = null, tint = Color(0xFF25D366))
                            },
                            onClick = {
                                showOptionsMenu = false
                                val shareText = "Olá, entro em contato referente aos atendimentos no CIADI+ para ${selectedGroup.pacienteNome ?: "assistido"}."
                                val url = "https://api.whatsapp.com/send?text=${Uri.encode(shareText)}"
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(intent)
                            }
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = CIADIColors.Brown
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(CIADIColors.BackgroundLight)
        ) {
            // Lista de Mensagens
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(localMessages) { msg ->
                    val isMe = msg.autorNome == user.fullName || msg.autorId == user.id
                    ChatMessageBubble(msg = msg, isMe = isMe)
                }
            }

            // Barra de Envio com Botão de Anexos
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 8.dp)
                ) {
                    IconButton(onClick = { showAttachmentSheet = true }) {
                        Icon(
                            imageVector = Icons.Default.AttachFile,
                            contentDescription = "Anexar",
                            tint = CIADIColors.OrangePrimary
                        )
                    }

                    OutlinedTextField(
                        value = messageInput,
                        onValueChange = { messageInput = it },
                        placeholder = { Text("Escreva uma mensagem segura...", fontSize = 14.sp) },
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.weight(1f)
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    IconButton(
                        onClick = {
                            if (messageInput.isNotBlank()) {
                                val newMsg = ChatMensagemDto(
                                    id = System.currentTimeMillis().toString(),
                                    grupoId = selectedGroup.id,
                                    autorId = user.id,
                                    autorNome = user.fullName,
                                    conteudo = messageInput.trim(),
                                    criadoEm = "Agora"
                                )
                                localMessages.add(newMsg)
                                messageInput = ""
                                scope.launch {
                                    modulesRepository?.enviarMensagem(newMsg)
                                }
                            }
                        }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(CIADIColors.TealPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Enviar",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }

        // Modal Bottom Sheet para Anexos Oficiais
        if (showAttachmentSheet) {
            ModalBottomSheet(
                onDismissRequest = { showAttachmentSheet = false },
                sheetState = rememberModalBottomSheetState()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "Anexar ao Chat Seguro (Supabase Storage)",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = CIADIColors.Brown
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        AttachmentOption(
                            icon = Icons.Default.Description,
                            label = "Documento",
                            onClick = {
                                showAttachmentSheet = false
                                scope.launch {
                                    snackbarHostState.showSnackbar("Seleção de Documento Clínico autorizada.")
                                }
                            }
                        )

                        AttachmentOption(
                            icon = Icons.Default.CameraAlt,
                            label = "Câmara",
                            onClick = {
                                showAttachmentSheet = false
                                scope.launch {
                                    snackbarHostState.showSnackbar("Captura via câmara para anexo seguro.")
                                }
                            }
                        )

                        AttachmentOption(
                            icon = Icons.Default.Image,
                            label = "Galeria",
                            onClick = {
                                showAttachmentSheet = false
                                scope.launch {
                                    snackbarHostState.showSnackbar("Seletor de foto PhotoPicker pronto.")
                                }
                            }
                        )

                        AttachmentOption(
                            icon = Icons.Default.Folder,
                            label = "Ficheiro",
                            onClick = {
                                showAttachmentSheet = false
                                scope.launch {
                                    snackbarHostState.showSnackbar("Explorador de arquivos preparado.")
                                }
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}

@Composable
private fun AttachmentOption(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(CIADIColors.CreamLight),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = label, tint = CIADIColors.OrangePrimary)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = label, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun ChatMessageBubble(msg: ChatMensagemDto, isMe: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isMe) Arrangement.End else Arrangement.Start
    ) {
        Card(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isMe) 16.dp else 4.dp,
                bottomEnd = if (isMe) 4.dp else 16.dp
            ),
            colors = CardDefaults.cardColors(
                containerColor = if (isMe) CIADIColors.TealPrimary else Color.White
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier.fillMaxWidth(0.82f)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                if (!isMe) {
                    Text(
                        text = msg.autorNome ?: "Equipe CIADI",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = CIADIColors.OrangePrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }

                Text(
                    text = msg.conteudo,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (isMe) Color.White else CIADIColors.Brown
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = msg.criadoEm ?: "",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 10.sp,
                    color = if (isMe) Color.White.copy(alpha = 0.7f) else CIADIColors.TextSecondary,
                    modifier = Modifier.align(Alignment.End)
                )
            }
        }
    }
}
