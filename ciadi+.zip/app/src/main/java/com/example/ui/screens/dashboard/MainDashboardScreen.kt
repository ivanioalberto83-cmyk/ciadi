package com.example.ui.screens.dashboard

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ChildCare
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.remote.dto.PacienteDto
import com.example.data.remote.dto.PortalAgendamentoDto
import com.example.data.repository.SupabaseModulesRepositoryImpl
import com.example.domain.model.SupabaseStatus
import com.example.domain.model.UserProfile
import com.example.domain.model.UserRole
import com.example.domain.repository.ModulesRepository
import com.example.ui.components.CiadiDynamicBackground
import com.example.ui.components.CiadiTopBar
import com.example.ui.components.RoleBadge
import com.example.ui.designsystem.CIADIBadge
import com.example.ui.designsystem.CIADIBottomBar
import com.example.ui.designsystem.CIADIButtons
import com.example.ui.designsystem.CIADICards
import com.example.ui.designsystem.CIADIShapes
import com.example.ui.theme.CIADIColors

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MainDashboardScreen(
    user: UserProfile,
    supabaseStatus: SupabaseStatus,
    onRoleSwitch: (UserRole) -> Unit,
    onNavigateToModule: (String) -> Unit,
    onNavigateToJaneth: () -> Unit,
    onNavigateToProfile: () -> Unit,
    onNavigateToSos: () -> Unit,
    onNavigateToVirtualClinic: (PortalAgendamentoDto?) -> Unit,
    modulesRepository: ModulesRepository? = null,
    modifier: Modifier = Modifier
) {
    val repoImpl = modulesRepository as? SupabaseModulesRepositoryImpl

    val patientsFlow = remember(repoImpl) {
        repoImpl?.observeAuthorizedPatients() ?: kotlinx.coroutines.flow.MutableStateFlow(emptyList<PacienteDto>())
    }
    val authorizedPatients by patientsFlow.collectAsState()

    val selectedPatientFlow = remember(repoImpl) {
        repoImpl?.observeSelectedPatient() ?: kotlinx.coroutines.flow.MutableStateFlow<PacienteDto?>(null)
    }
    val selectedPatient by selectedPatientFlow.collectAsState()

    val agendamentosFlow = remember(repoImpl) {
        repoImpl?.observePortalAgendamentos() ?: kotlinx.coroutines.flow.MutableStateFlow(emptyList<PortalAgendamentoDto>())
    }
    val agendamentosPortal by agendamentosFlow.collectAsState()

    LaunchedEffect(Unit) {
        repoImpl?.syncFamilyBonds()
        repoImpl?.fetchPortalAgendamentos(user.id)
    }

    // Próxima consulta ativa do assistido
    val proximaConsulta: PortalAgendamentoDto? = remember(agendamentosPortal) {
        agendamentosPortal.firstOrNull { item ->
            item.estado?.equals("concluida", ignoreCase = true) != true &&
                    item.estado?.equals("cancelada", ignoreCase = true) != true &&
                    item.estado?.equals("finalizado", ignoreCase = true) != true
        }
    }

    Scaffold(
        topBar = {
            CiadiTopBar(
                title = "CIADI+",
                currentUser = user,
                onProfileClick = onNavigateToProfile,
                onJanethClick = onNavigateToJaneth
            )
        },
        bottomBar = {
            CIADIBottomBar(
                currentRoute = "dashboard",
                onNavigate = { route ->
                    when (route) {
                        "dashboard" -> Unit
                        "agenda" -> onNavigateToModule("agenda")
                        "tracking" -> onNavigateToModule("tracking")
                        "janeth" -> onNavigateToJaneth()
                        "profile" -> onNavigateToProfile()
                    }
                }
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        CiadiDynamicBackground(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
            // 1. Cabeçalho Oficial CIADI+
            item {
                CIADICards.Base(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_ciadi_logo_1790332105105),
                                contentDescription = "Logo Oficial CIADI",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .size(50.dp)
                                    .clip(RoundedCornerShape(12.dp))
                            )
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Olá, vamos cuidar juntos.",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = CIADIColors.Brown,
                                        fontSize = 17.sp
                                    )
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Responsável: ${user.fullName}",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = CIADIColors.TextSecondary,
                                        fontSize = 12.sp
                                    )
                                )
                            }
                            RoleBadge(role = user.role)
                        }
                    }
                }
            }

            // 2. Criança Acompanhada (Cartão Visual Destacado)
            item {
                CIADICards.Warm(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(CIADIColors.OrangePrimary),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ChildCare,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Criança Acompanhada",
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = CIADIColors.Brown
                                        )
                                    )
                                    Text(
                                        text = "Vinculada no Supabase via RLS",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = CIADIColors.TextSecondary,
                                            fontSize = 11.sp
                                        )
                                    )
                                }
                            }

                            if (authorizedPatients.size > 1) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(CIADIColors.Cream)
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "${authorizedPatients.size} assistidos",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = CIADIColors.Brown
                                        )
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        if (authorizedPatients.isEmpty()) {
                            // Se nenhum retorno do backend ainda
                            val fallback = user.activePatientName ?: "Assistido vinculado ao responsável"
                            Text(
                                text = fallback,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = CIADIColors.TextPrimary
                                )
                            )
                        } else if (authorizedPatients.size == 1) {
                            val child = authorizedPatients.first()
                            Text(
                                text = child.nome,
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = CIADIColors.TextPrimary,
                                    fontSize = 20.sp
                                )
                            )
                            if (!child.diagnosticoResumo.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = child.diagnosticoResumo,
                                    style = MaterialTheme.typography.bodySmall.copy(color = CIADIColors.TextSecondary)
                                )
                            }
                            if (proximaConsulta != null) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Próximo compromisso: ${proximaConsulta.especialidade} (${proximaConsulta.dataHora})",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = CIADIColors.OrangePrimary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                            }
                        } else {
                            // Múltiplas crianças: Exige seleção explícita sem auto-seleção
                            Text(
                                text = "Selecionar criança:",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    color = CIADIColors.Brown
                                )
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                authorizedPatients.forEach { paciente ->
                                    val isSelected = selectedPatient?.id == paciente.id
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { repoImpl?.selectPatient(paciente) },
                                        label = {
                                            Text(
                                                text = paciente.nome,
                                                fontSize = 12.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                            )
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = CIADIColors.OrangePrimary,
                                            selectedLabelColor = Color.White
                                        ),
                                        modifier = Modifier.testTag("child_chip_${paciente.id}")
                                    )
                                }
                            }

                            selectedPatient?.let { sel ->
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Assistido ativo: ${sel.nome}",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = CIADIColors.OrangePrimary
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // 3. Card Grande: Próxima Consulta
            item {
                CIADICards.Base(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Próxima consulta",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = CIADIColors.Brown
                                )
                            )
                            Text(
                                text = "Ver Calendário",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = CIADIColors.OrangePrimary
                                ),
                                modifier = Modifier.clickable { onNavigateToModule("agenda") }
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        if (proximaConsulta != null) {
                            val isOnline = proximaConsulta.modalidade?.equals("Online", ignoreCase = true) == true || !proximaConsulta.linkVideo.isNullOrBlank()

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = proximaConsulta.especialidade ?: "Consulta Clínica",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = CIADIColors.TextPrimary
                                        )
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "Profissional: ${proximaConsulta.profissional ?: "Equipe CIADI"}",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = CIADIColors.TextSecondary
                                        )
                                    )
                                }
                                CIADIBadge.Modalidade(isOnline = isOnline)
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(CIADIColors.CreamLight)
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AccessTime,
                                    contentDescription = null,
                                    tint = CIADIColors.Brown,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = proximaConsulta.dataHora,
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = CIADIColors.TextPrimary
                                    )
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "(${proximaConsulta.estado ?: "Confirmada"})",
                                    style = MaterialTheme.typography.labelSmall.copy(color = CIADIColors.SuccessGreen)
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            if (isOnline) {
                                CIADIButtons.Primary(
                                    text = "ENTRAR NA CONSULTA",
                                    onClick = { onNavigateToVirtualClinic(proximaConsulta) },
                                    icon = Icons.Default.Videocam,
                                    modifier = Modifier.testTag("home_enter_virtual_consultation")
                                )
                            } else {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Business, contentDescription = null, tint = CIADIColors.TextSecondary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Atendimento presencial na unidade principal do CIADI.",
                                        style = MaterialTheme.typography.bodySmall.copy(color = CIADIColors.TextSecondary)
                                    )
                                }
                            }
                        } else {
                            Text(
                                text = "Nenhuma consulta pendente no momento.",
                                style = MaterialTheme.typography.bodyMedium.copy(color = CIADIColors.TextSecondary)
                            )
                        }
                    }
                }
            }

            // 4. Acesso Rápido (Cartões Grandes)
            item {
                Text(
                    text = "Acesso Rápido",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = CIADIColors.Brown
                    )
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    BigAccessCard(
                        title = "Calendário",
                        subtitle = "Ver horários",
                        icon = Icons.Default.CalendarMonth,
                        iconColor = CIADIColors.OrangePrimary,
                        onClick = { onNavigateToModule("agenda") },
                        modifier = Modifier.weight(1f)
                    )
                    BigAccessCard(
                        title = "Clínica Virtual",
                        subtitle = "Teleconsulta",
                        icon = Icons.Default.Videocam,
                        iconColor = CIADIColors.TealPrimary,
                        onClick = { onNavigateToVirtualClinic(proximaConsulta) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    BigAccessCard(
                        title = "Acompanhamento",
                        subtitle = "Metas & P.E.I.",
                        icon = Icons.Default.Timeline,
                        iconColor = CIADIColors.Brown,
                        onClick = { onNavigateToModule("tracking") },
                        modifier = Modifier.weight(1f)
                    )
                    BigAccessCard(
                        title = "SOS",
                        subtitle = "Emergência rápida",
                        icon = Icons.Default.Warning,
                        iconColor = CIADIColors.ErrorRed,
                        onClick = onNavigateToSos,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // 5. Card da Janeth (Assistente Oficial Integrada)
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToJaneth() }
                        .testTag("dashboard_janeth_banner"),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = CIADIColors.Cream)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.janeth_avatar_1790333481531),
                            contentDescription = "Janeth Assistente",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(52.dp)
                                .clip(CircleShape)
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Converse com a Janeth",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = CIADIColors.Brown
                                )
                            )
                            Text(
                                text = "Tire dúvidas sobre serviços, consultas e orientações de rotina",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = CIADIColors.TextSecondary,
                                    fontSize = 12.sp
                                )
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = CIADIColors.Brown
                        )
                    }
                }
            }
        }
        }
    }
}

@Composable
private fun BigAccessCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(100.dp)
            .clickable { onClick() }
            .testTag("big_access_${title.lowercase()}"),
        shape = CIADIShapes.Large,
        colors = CardDefaults.cardColors(containerColor = CIADIColors.SurfaceWhite),
        border = androidx.compose.foundation.BorderStroke(1.dp, CIADIColors.Outline),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(iconColor.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = iconColor,
                    modifier = Modifier.size(20.dp)
                )
            }
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = CIADIColors.TextPrimary,
                        fontSize = 14.sp
                    )
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = CIADIColors.TextSecondary,
                        fontSize = 11.sp
                    )
                )
            }
        }
    }
}
