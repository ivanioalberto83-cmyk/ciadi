package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.domain.model.UserProfile
import com.example.domain.model.UserRole
import com.example.domain.model.UserSession
import com.example.domain.repository.AuthRepository
import com.example.domain.repository.ModulesRepository
import com.example.ui.screens.agenda.AgendaModuleScreen
import com.example.ui.screens.chat.ChatModuleScreen
import com.example.ui.screens.dashboard.MainDashboardScreen
import com.example.ui.screens.documents.DocumentsModuleScreen
import com.example.ui.screens.forms.FormsModuleScreen
import com.example.ui.screens.janeth.JanethScreen
import com.example.ui.screens.login.LoginScreen
import com.example.ui.screens.login.LoginViewModel
import com.example.ui.screens.notifications.NotificationsModuleScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.sos.SosScreen
import com.example.ui.screens.splash.SplashScreen
import com.example.ui.screens.tracking.TrackingModuleScreen
import com.example.ui.screens.virtualclinic.ClinicaVirtualScreen
import com.example.ui.screens.virtualclinic.SalaVideoScreen
import com.example.data.remote.dto.PortalAgendamentoDto
import androidx.compose.runtime.mutableStateOf
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun AppNavigation(
    authRepository: AuthRepository,
    modulesRepository: ModulesRepository? = null,
    navController: NavHostController = rememberNavController(),
    modifier: Modifier = Modifier
) {
    val session by authRepository.sessionFlow.collectAsState()
    val supabaseStatus = remember { authRepository.getSupabaseStatus() }

    val fallbackUser = remember {
        UserProfile(
            id = "",
            email = "",
            fullName = "Utilizador CIADI+",
            role = UserRole.RESPONSAVEL,
            activePatientName = null
        )
    }

    val activeUser = (session as? UserSession.Authenticated)?.user ?: fallbackUser

    val activeMeetingForVideo = remember { mutableStateOf<PortalAgendamentoDto?>(null) }

    NavHost(
        navController = navController,
        startDestination = NavRoute.Splash.route,
        modifier = modifier
    ) {
        composable(NavRoute.Splash.route) {
            SplashScreen(
                session = session,
                onNavigateToDashboard = {
                    navController.navigate(NavRoute.Dashboard.route) {
                        popUpTo(NavRoute.Splash.route) { inclusive = true }
                    }
                },
                onNavigateToLogin = {
                    navController.navigate(NavRoute.Login.route) {
                        popUpTo(NavRoute.Splash.route) { inclusive = true }
                    }
                }
            )
        }

        composable(NavRoute.Login.route) {
            val loginViewModel = remember { LoginViewModel(authRepository) }
            LoginScreen(
                viewModel = loginViewModel,
                onLoginSuccess = {
                    navController.navigate(NavRoute.Dashboard.route) {
                        popUpTo(NavRoute.Login.route) { inclusive = true }
                    }
                }
            )
        }

        composable(NavRoute.Dashboard.route) {
            MainDashboardScreen(
                user = activeUser,
                supabaseStatus = supabaseStatus,
                onRoleSwitch = { role ->
                    authRepository.switchRoleForPreview(role)
                },
                onNavigateToModule = { route ->
                    when (route) {
                        "module_agenda", "agenda" -> navController.navigate(NavRoute.Agenda.route)
                        "module_tracking", "tracking" -> navController.navigate(NavRoute.Tracking.route)
                        "module_forms", "forms" -> navController.navigate(NavRoute.Forms.route)
                        "module_documents", "documents" -> navController.navigate(NavRoute.Documents.route)
                        "module_chat", "chat" -> navController.navigate(NavRoute.Chat.route)
                        "module_notifications", "notifications" -> navController.navigate(NavRoute.Notifications.route)
                    }
                },
                onNavigateToJaneth = {
                    navController.navigate(NavRoute.Janeth.route)
                },
                onNavigateToProfile = {
                    navController.navigate(NavRoute.Profile.route)
                },
                onNavigateToSos = {
                    navController.navigate(NavRoute.Sos.route)
                },
                onNavigateToVirtualClinic = { agendamento ->
                    activeMeetingForVideo.value = agendamento
                    navController.navigate(NavRoute.VirtualClinic.route)
                },
                modulesRepository = modulesRepository
            )
        }

        composable(NavRoute.VirtualClinic.route) {
            ClinicaVirtualScreen(
                user = activeUser,
                onNavigateBack = { navController.popBackStack() },
                onEnterVideoRoom = { meeting ->
                    activeMeetingForVideo.value = meeting
                    navController.navigate(NavRoute.VideoRoom.route)
                },
                modulesRepository = modulesRepository
            )
        }

        composable(NavRoute.VideoRoom.route) {
            val meeting = activeMeetingForVideo.value ?: PortalAgendamentoDto(
                id = "sala_demo",
                especialidade = "Consulta Clínica",
                profissional = "Equipe CIADI",
                paciente = activeUser.activePatientName ?: "Assistido",
                dataHora = "Hoje",
                modalidade = "Online",
                linkVideo = "https://ciadi.org.br/sala/demo"
            )
            SalaVideoScreen(
                user = activeUser,
                agendamento = meeting,
                onNavigateBack = { navController.popBackStack() },
                modulesRepository = modulesRepository
            )
        }

        composable(NavRoute.Sos.route) {
            SosScreen(
                user = activeUser,
                onNavigateBack = { navController.popBackStack() },
                modulesRepository = modulesRepository
            )
        }

        composable(NavRoute.Janeth.route) {
            JanethScreen(
                user = activeUser,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(NavRoute.Agenda.route) {
            AgendaModuleScreen(
                user = activeUser,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToVirtualClinic = { agendamento ->
                    activeMeetingForVideo.value = agendamento
                    navController.navigate(NavRoute.VirtualClinic.route)
                },
                onNavigateToRoute = { route ->
                    when (route) {
                        "dashboard" -> navController.navigate(NavRoute.Dashboard.route) { popUpTo(NavRoute.Dashboard.route) { inclusive = true } }
                        "agenda" -> Unit
                        "virtual_clinic" -> navController.navigate(NavRoute.VirtualClinic.route)
                        "tracking" -> navController.navigate(NavRoute.Tracking.route)
                        "janeth" -> navController.navigate(NavRoute.Janeth.route)
                    }
                },
                modulesRepository = modulesRepository
            )
        }

        composable(NavRoute.Tracking.route) {
            TrackingModuleScreen(
                user = activeUser,
                onNavigateBack = { navController.popBackStack() },
                modulesRepository = modulesRepository
            )
        }

        composable(NavRoute.Forms.route) {
            FormsModuleScreen(
                user = activeUser,
                onNavigateBack = { navController.popBackStack() },
                modulesRepository = modulesRepository
            )
        }

        composable(NavRoute.Documents.route) {
            DocumentsModuleScreen(
                user = activeUser,
                onNavigateBack = { navController.popBackStack() },
                modulesRepository = modulesRepository
            )
        }

        composable(NavRoute.Chat.route) {
            ChatModuleScreen(
                user = activeUser,
                onNavigateBack = { navController.popBackStack() },
                modulesRepository = modulesRepository
            )
        }

        composable(NavRoute.Notifications.route) {
            NotificationsModuleScreen(
                user = activeUser,
                onNavigateBack = { navController.popBackStack() },
                modulesRepository = modulesRepository
            )
        }

        composable(NavRoute.Profile.route) {
            ProfileScreen(
                user = activeUser,
                onNavigateBack = { navController.popBackStack() },
                onSignOut = {
                    CoroutineScope(Dispatchers.Main).launch {
                        authRepository.signOut()
                        navController.navigate(NavRoute.Login.route) {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                }
            )
        }
    }
}
