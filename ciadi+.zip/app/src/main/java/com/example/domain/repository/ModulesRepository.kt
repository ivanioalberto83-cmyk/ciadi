package com.example.domain.repository

import com.example.data.remote.dto.AgendamentoDto
import com.example.data.remote.dto.AtIncidenteDto
import com.example.data.remote.dto.AtRegistoObjetivoDto
import com.example.data.remote.dto.AtSessaoDto
import com.example.data.remote.dto.AtSupervisaoDto
import com.example.data.remote.dto.AtribuicaoAtDto
import com.example.data.remote.dto.ChatGrupoDto
import com.example.data.remote.dto.ChatMensagemDto
import com.example.data.remote.dto.DocumentoClinicoDto
import com.example.data.remote.dto.FormularioClinicoDto
import com.example.data.remote.dto.NotificacaoDto
import com.example.data.remote.dto.PacienteDto
import com.example.data.remote.dto.VinculoFamiliarDto
import kotlinx.coroutines.flow.Flow

/**
 * Contrato do repositório dos módulos do ecossistema CIADI+.
 * Consome exclusivamente o projeto Supabase real com RLS.
 */
interface ModulesRepository {

    // 1. Família / Vínculos
    fun observeCriancasVinculadas(): Flow<List<VinculoFamiliarDto>>
    fun observePacientes(): Flow<List<PacienteDto>>

    // 2. Acompanhante Terapêutico (A.T.)
    fun observeAtribuicoesAt(): Flow<List<AtribuicaoAtDto>>
    fun observeAtSessoes(atribuicaoId: String? = null): Flow<List<AtSessaoDto>>
    fun observeAtRegistosObjetivos(sessaoId: String? = null): Flow<List<AtRegistoObjetivoDto>>
    fun observeAtIncidentes(sessaoId: String? = null): Flow<List<AtIncidenteDto>>
    fun observeAtSupervisoes(): Flow<List<AtSupervisaoDto>>

    suspend fun registrarSessaoAt(sessao: AtSessaoDto): Result<AtSessaoDto>
    suspend fun registrarIncidenteAt(incidente: AtIncidenteDto): Result<AtIncidenteDto>
    suspend fun registrarObjetivoAt(registro: AtRegistoObjetivoDto): Result<AtRegistoObjetivoDto>

    // 3. Agenda & Agendamentos
    fun observeAgendamentos(pacienteId: String? = null, profissionalId: String? = null): Flow<List<AgendamentoDto>>
    suspend fun criarAgendamento(agendamento: AgendamentoDto): Result<AgendamentoDto>

    // 4. Formulários Clínicos
    fun observeFormulariosClinicos(): Flow<List<FormularioClinicoDto>>

    // 5. Documentos Clínicos & A4
    fun observeDocumentosClinicos(pacienteId: String? = null): Flow<List<DocumentoClinicoDto>>
    suspend fun emitirDocumentoClinico(documento: DocumentoClinicoDto): Result<DocumentoClinicoDto>

    // 6. Chat CIADI+
    fun observeChatGrupos(): Flow<List<ChatGrupoDto>>
    fun observeChatMensagens(grupoId: String): Flow<List<ChatMensagemDto>>
    suspend fun enviarMensagem(mensagem: ChatMensagemDto): Result<ChatMensagemDto>

    // 7. Notificações
    fun observeNotificacoes(): kotlinx.coroutines.flow.StateFlow<List<NotificacaoDto>>
    suspend fun marcarNotificacaoLida(id: String): Result<Unit>

    // Sincronização geral
    suspend fun sincronizarTabela(nomeTabela: String): Result<Unit>
}
