package com.example.domain.repository

import com.example.data.remote.dto.AtIncidenteDto
import com.example.data.remote.dto.AtRegistoObjetivoDto
import com.example.data.remote.dto.AtSessaoDto
import com.example.data.remote.dto.AtSupervisaoDto
import com.example.data.remote.dto.AtribuicaoAtDto
import kotlinx.coroutines.flow.StateFlow

/**
 * Repositório oficial para Acompanhante Terapêutico (A.T.) no CIADI+.
 * Fluxo: Atribuição → Paciente → Agenda → Sessão → Objetivos → Registo → Incidente → Supervisão
 */
interface ATRepository {
    fun observeAtribuicoes(): StateFlow<List<AtribuicaoAtDto>>
    fun observeSessoes(): StateFlow<List<AtSessaoDto>>
    fun observeRegistosObjetivos(): StateFlow<List<AtRegistoObjetivoDto>>
    fun observeIncidentes(): StateFlow<List<AtIncidenteDto>>
    fun observeSupervisoes(): StateFlow<List<AtSupervisaoDto>>

    suspend fun registrarSessao(sessao: AtSessaoDto): Result<AtSessaoDto>
    suspend fun registrarObjetivo(objetivo: AtRegistoObjetivoDto): Result<AtRegistoObjetivoDto>
    suspend fun registrarIncidente(incidente: AtIncidenteDto): Result<AtIncidenteDto>
    suspend fun syncATData(): Result<Unit>
}
