package com.example.domain.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.CIADIColors

/**
 * Perfis de acesso do ecossistema oficial CIADI+.
 *
 * Mapeados diretamente para a coluna 'role' da tabela 'perfis' e claims do Supabase/PostgreSQL com RLS.
 */
enum class UserRole(
    val label: String,
    val description: String,
    val badgeColor: Color,
    val code: String
) {
    RESPONSAVEL(
        label = "Família / Responsável",
        description = "Acompanhamento do assistido vinculado, rotinas, agenda e P.E.I.",
        badgeColor = CIADIColors.RoleFamily,
        code = "responsavel"
    ),
    AT(
        label = "A.T. — Acompanhante Terapêutico",
        description = "Registros diários em campo/escola, evolução de metas, sessões e ocorrências",
        badgeColor = CIADIColors.RoleAt,
        code = "at"
    ),
    PROFISSIONAL(
        label = "Profissional Especializado",
        description = "Equipe multidisciplinar (Psicologia, Fala, Ocupacional, Pediatria)",
        badgeColor = CIADIColors.RoleProfessional,
        code = "profissional"
    ),
    GESTOR(
        label = "Gestão & Coordenação",
        description = "Supervisão clínica, coordenação de equipe e fluxos de atendimento",
        badgeColor = CIADIColors.RoleGestor,
        code = "gestor"
    ),
    ADMIN(
        label = "Administração",
        description = "Gestão global da unidade, auditoria e políticas de segurança RLS",
        badgeColor = CIADIColors.RoleAdmin,
        code = "admin"
    ),
    PACIENTE(
        label = "Assistido / Paciente",
        description = "Acesso adaptado para o assistido/aprendiz em desenvolvimento",
        badgeColor = CIADIColors.OrangePrimary,
        code = "paciente"
    ),
    OPERADOR(
        label = "Operador / Secretaria",
        description = "Recepção, triagem inicial e agendamentos de salas",
        badgeColor = CIADIColors.RoleOperador,
        code = "operador"
    );

    companion object {
        fun fromCode(code: String?): UserRole {
            val normalized = code?.trim()?.lowercase() ?: return RESPONSAVEL
            return entries.firstOrNull { it.code.equals(normalized, ignoreCase = true) }
                ?: when (normalized) {
                    "at", "at_terapeutico", "acompanhante", "acompanhante_terapeutico", "therapeutic_companion" -> AT
                    "responsavel", "responsável", "familia", "família", "family", "mae", "pai", "tutor" -> RESPONSAVEL
                    "profissional", "terapeuta", "especialista", "medico", "médico", "psicologia" -> PROFISSIONAL
                    "gestor", "coordenador", "coordenação", "coordenacao", "gestao", "gestão" -> GESTOR
                    "admin", "administrador", "administração", "administracao", "direcao", "direção" -> ADMIN
                    "paciente", "assistido", "crianca", "criança" -> PACIENTE
                    "operador", "secretaria", "secretária", "recepcao", "recepção" -> OPERADOR
                    else -> RESPONSAVEL
                }
        }
    }
}
