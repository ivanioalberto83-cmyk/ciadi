package com.example.domain.repository

import com.example.data.remote.dto.ChatGrupoDto
import com.example.data.remote.dto.ChatMensagemDto
import kotlinx.coroutines.flow.StateFlow

/**
 * Repositório oficial para Chat & Mensagens no CIADI+.
 * Consome 'ciadi_chat_grupos', 'ciadi_chat_membros' e 'ciadi_chat_mensagens' do Supabase.
 */
interface ChatRepository {
    fun observeGrupos(): StateFlow<List<ChatGrupoDto>>
    fun observeMensagens(grupoId: String): StateFlow<List<ChatMensagemDto>>
    suspend fun enviarMensagem(mensagem: ChatMensagemDto): Result<ChatMensagemDto>
    suspend fun syncChat(): Result<Unit>
}
