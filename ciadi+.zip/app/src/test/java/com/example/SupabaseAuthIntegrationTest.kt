package com.example

import com.example.core.config.SupabaseConfig
import com.example.data.remote.dto.SupabaseSignInRequest
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.concurrent.TimeUnit

class SupabaseAuthIntegrationTest {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    @Test
    fun testSupabaseConfigurationAndHealth() {
        assertEquals("https://egpkkttbcaukqnnxyhjv.supabase.co", SupabaseConfig.OFFICIAL_CIADI_SUPABASE_URL)
        assertEquals("https://egpkkttbcaukqnnxyhjv.supabase.co", SupabaseConfig.supabaseUrl)
        assertTrue(SupabaseConfig.supabaseAnonKey.startsWith("sb_publishable_"))
        assertTrue(SupabaseConfig.isConfigured)

        val healthRequest = Request.Builder()
            .url("${SupabaseConfig.supabaseUrl}/auth/v1/health")
            .header("apikey", SupabaseConfig.supabaseAnonKey)
            .get()
            .build()

        val response = client.newCall(healthRequest).execute()
        assertEquals(200, response.code)
        val body = response.body?.string()
        assertNotNull(body)
        assertTrue(body!!.contains("GoTrue"))
    }

    @Test
    fun testSupabaseAuthPasswordEndpointRejectionOnInvalidCredentials() {
        val adapter = moshi.adapter(SupabaseSignInRequest::class.java)
        val json = adapter.toJson(SupabaseSignInRequest("test_inexistente@ciadi.org.br", "senha_incorreta_123"))

        val authRequest = Request.Builder()
            .url(SupabaseConfig.tokenUrl)
            .header("apikey", SupabaseConfig.supabaseAnonKey)
            .header("Content-Type", "application/json")
            .post(json.toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(authRequest).execute()
        // Supabase GoTrue returns HTTP 400 with invalid_credentials for bad credentials
        assertEquals(400, response.code)
        val body = response.body?.string()
        assertNotNull(body)
        assertTrue(body!!.contains("invalid_credentials") || body.contains("Invalid login credentials"))
    }

    @Test
    fun testPerfisTableEnforcesRowLevelSecurity() {
        val request = Request.Builder()
            .url("${SupabaseConfig.supabaseUrl}/rest/v1/perfis?select=*")
            .header("apikey", SupabaseConfig.supabaseAnonKey)
            .get()
            .build()

        val response = client.newCall(request).execute()
        assertEquals(200, response.code)
        val body = response.body?.string()
        assertNotNull(body)
        // Without an authenticated user JWT, RLS returns empty list [] instead of leaking profiles
        assertEquals("[]", body!!.trim())
    }
}
